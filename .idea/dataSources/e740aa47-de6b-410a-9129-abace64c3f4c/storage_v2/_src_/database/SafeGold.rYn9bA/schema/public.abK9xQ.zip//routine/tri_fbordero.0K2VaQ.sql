create function tri_fbordero() returns trigger
    language plpgsql
as
$$
DECLARE
  v_dtx       date;
  v_x         integer;
  v_advlr_iof numeric;
begin

  if TG_OP in ('INSERT') then
     new.bor_dtsis := now();
  else
     new.bor_dtupdate := now();
  end if;
  v_advlr_iof := 0;
  select sum(tab_valor) into v_advlr_iof
    from fbortarifa bot, dtarifa tar
   where bot.bor_id = new.bor_id
     and tar.tar_id = bot.tar_id
     and (tar.tar_desagio = 'S' or tar.tar_advalorem = 'S');
     
  select sum(tab_valor) into new.bor_vlr_tot_tarifas
    from fbortarifa bot
   where bot.bor_id = new.bor_id;

  new.bor_vlr_bruto_final := coalesce(new.bor_vlr_bruto,0)-coalesce(new.bor_vlr_bruto_recusado,0);
  new.bor_qtd_final := coalesce(new.bor_qtd_tit,0)-coalesce(new.bor_qt_recusada,0);
  new.bor_float_calc := coalesce(new.bor_pz_med_bco,0)-coalesce(new.bor_pz_med_emp,0);
  new.bor_float_dif := coalesce(new.bor_float_calc,0)-coalesce(new.bor_float_acordado,0);
  if new.bor_float_dif < 0 then
     new.bor_float_dif := 0;
  end if;
  new.bor_chk_iof := round(((new.bor_vlr_bruto_final-v_advlr_iof)*coalesce(new.bor_pz_med_bco,0)*0.000041)+((new.bor_vlr_bruto_final-v_advlr_iof)*0.0038),2);
  new.bor_vlr_liquido := new.bor_vlr_bruto_final - new.bor_vlr_tot_tarifas;
  new.bor_vlr_liq_correto := round((new.bor_vlr_bruto_final-(new.bor_vlr_bruto_final^((1/30)*(new.bor_pz_med_emp+new.bor_float_acordado)))/100),2);
--                             ROUND((new.bor_vlr_bruto_final-(new.bor_vlr_bruto_final^((1/30)*(new.bor_pz_med_emp+new.bor_float_acordado)))/100),2) liquido_correto,
--  new.bor_vlr_liq_correto := round((new.bor_vlr_bruto_final-(new.bor_vlr_bruto_final^((round(new.bor_cst_com_iof/30,4))*(new.bor_pz_med_emp+new.bor_float_acordado)))/100),2);
  new.bor_chk_liq := new.bor_vlr_liquido-new.bor_vlr_liq_correto;
  if new.bor_chk_liq < 0 then
     new.bor_status = 'Diferença';
  else
     new.bor_status = 'Ok';
  end if;
  if coalesce(new.bor_vlr_liquido,0) = 0 then
      new.bor_per_recompra := 0;
      new.bor_per_retencao := 0;
      new.bor_per_fomento  := 0;
      new.bor_per_outros   := 0;
  else
      new.bor_per_recompra := round(((new.bor_recompra/new.bor_vlr_liquido)*100),2);
      new.bor_per_retencao := round(((new.bor_retencao/new.bor_vlr_liquido)*100),2);
      new.bor_per_fomento  := round(((new.bor_fomento/new.bor_vlr_liquido)*100),2);
      new.bor_per_outros   := round(((new.bor_outros_cst/new.bor_vlr_liquido)*100),2);
  end if;
  new.bor_liq_recebido := new.bor_vlr_liquido-new.bor_recompra-new.bor_retencao-new.bor_fomento-new.bor_outros_cst;
  if coalesce(new.bor_pz_med_emp,0) = 0 then
     new.bor_cst_efetivo := 0;
  else
     new.bor_cst_efetivo  := (((new.bor_vlr_bruto_final-new.bor_vlr_liquido)/new.bor_vlr_liquido)*100)^(30/new.bor_pz_med_emp);
  end if;
  if (coalesce(new.bor_pz_med_emp,0)+coalesce(new.bor_float_acordado,0)) = 0 then
     new.bor_tx_empresa := 0;
  else
     new.bor_tx_empresa := (((new.bor_vlr_bruto_final-new.bor_vlr_liquido)/new.bor_vlr_liquido)*100)^(30/(new.bor_pz_med_emp+new.bor_float_acordado));
  end if;
/*  update zgiba set valor = v_juros, valor2 = new.bor_cst_com_iof/30, valor3 = new.bor_pz_med_emp
   where id = 5;*/
  Return New;
end;
$$;

alter function tri_fbordero() owner to safegold;

