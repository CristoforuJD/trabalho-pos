create function prc_atua_bordero(p_borid integer) returns void
    language plpgsql
as
$$
declare
--
-- Giba 06/2018 -- Primeira procedure da SafeGold ;-)
-- Atualiza bordero (liquido e etc) via trigger
--

begin
  update fbordero set bor_dtupdate = now()
   where bor_id = p_borid;
  return;
end;
$$;

alter function prc_atua_bordero(integer) owner to safegold;

