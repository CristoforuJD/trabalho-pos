create function x_prc_ordem_disponivel(p_proj integer) returns void
    strict
    language plpgsql
as
$$
declare
--
-- Giba 11/2016
-- Cria relacao das ordens disponivels para placonta de todos os projetos
--
v_count integer;
reg record;
pro record;
v_limite integer;
v_next   integer;
begin
 for pro in (select * from projeto where pro_id = p_proj)
 loop
   delete from pladisponivel where pro_id = pro.pro_id;
   for reg in (SELECT *
                 from planoconta
                where pro_id = pro.pro_id order  by pla_ordem)
   loop
      v_limite := null;
      -- Procura a proxima ordem ja utilizada maior que a corrente e na sequencia vai inserir
      -- mais ordens disponiveis ate o limite (proxima utilizada)
      select min(pla_ordem) into v_limite 
        from planoconta
       where pro_id = pro.pro_id
         and pla_ordem > reg.pla_ordem;
      if v_limite is null then
         v_limite := reg.pla_ordem + 1000;
      end if;
      insert into pladisponivel (pro_id,     pla_ordem,     pla_idpai,     pla_id)
                         values (reg.pro_id, reg.pla_ordem, reg.pla_idpai, reg.pla_id);
      v_next := reg.pla_ordem + 1;
      while v_next < v_limite
      loop
        if v_next > 200 then
           insert into pladisponivel (pro_id,     pla_ordem, pla_idpai,     pla_id)
                              values (reg.pro_id, v_next,    reg.pla_idpai, null);
        end if;
        v_next := v_next + 1;
      end loop;
   end loop;
 end loop;
 return;
end;
$$;

alter function x_prc_ordem_disponivel(integer) owner to dba;

