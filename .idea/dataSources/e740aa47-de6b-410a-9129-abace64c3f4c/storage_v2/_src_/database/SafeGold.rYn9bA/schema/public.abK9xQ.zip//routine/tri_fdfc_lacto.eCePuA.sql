create function tri_fdfc_lacto() returns trigger
    language plpgsql
as
$$
DECLARE
  v_dtx date;
  v_x   integer;
begin
  v_dtx := new.dfc_dtmovim;
  v_x := date_part('month',v_dtx);
  new.dfc_rmes := v_x;
  v_x := date_part('year',v_dtx);
  new.dfc_rano := v_x;
  Return New;
end;
$$;

alter function tri_fdfc_lacto() owner to dba;

