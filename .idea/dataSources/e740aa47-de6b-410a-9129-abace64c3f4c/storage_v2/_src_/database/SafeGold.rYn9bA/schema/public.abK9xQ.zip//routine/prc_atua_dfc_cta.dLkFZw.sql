create function prc_atua_dfc_cta(p_idcta integer, p_ano integer, p_mes integer, p_sub integer, p_valor numeric DEFAULT 0) returns void
    language plpgsql
as
$$
declare
--
-- Giba 10/2018
-- Atualiza o saldo de uma conta  recursivamente de um mes/ano de um sub-projeto
--
x        record;
begin
  if p_idcta is not null then
     for x in (select a.pla_idpai
                 from dplanoconta a
                where a.pla_id = p_idcta)
     loop
       update ddfcmes set dfm_saldo_real = dfm_saldo_real + p_valor
        where pla_id  = p_idcta
          and dfm_ano = p_ano
          and dfm_mes = p_mes
          and sub_id  = p_sub;
       perform prc_atua_dfc_cta (x.pla_idpai, p_ano, p_mes, p_sub, p_valor);
     end loop;
  end if;
  return;
end;
$$;

alter function prc_atua_dfc_cta(integer, integer, integer, integer, numeric) owner to dba;

