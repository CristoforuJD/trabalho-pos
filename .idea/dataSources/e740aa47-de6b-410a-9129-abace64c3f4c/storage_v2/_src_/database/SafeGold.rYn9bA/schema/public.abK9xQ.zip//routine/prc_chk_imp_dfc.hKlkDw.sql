create function prc_chk_imp_dfc(p_idimport integer) returns boolean
    language plpgsql
as
$$
declare
--
-- Giba 09/201
-- Confere importacao DFC
--
reg         record;
regi        record;
v_dt        timestamp;
v_msgerro   varchar(255);
v_forcli    integer;
v_count     integer;
v_erro      integer;
v_plaid     integer;
v_subid     integer;
v_doctedo   varchar(01);
v_proj      integer;
v_fornec    VARCHAR(100);

cr_clifor_razao cursor (vc_for varchar, vc_proj integer) is
                    select cli_id
                     from dclifor
                    where upper(trim(cli_nome)) = upper(trim(vc_for))
                      and pro_id = vc_proj;
                      
cr_clifor_cnpj cursor (vc_cnpj varchar, vc_proj integer) is
                    select cli_id
                     from dclifor
                    where upper(trim(cli_cnpjcpf)) = upper(trim(vc_cnpj))
                      and pro_id = vc_proj;


cr_planoconta cursor (vc_plano varchar, vc_proid integer) is
              select a.pla_id
                from dplanodepara a, dplanoconta b
               where a.pro_id = vc_proid
                 and UPPER(TRIM(a.dep_ctacli)) = UPPER(TRIM(vc_plano))
                 and b.pla_id = a.pla_id
                 and b.pla_totsn = 'N';
           
cr_subcon cursor (vc_origem varchar, vc_proj integer) is
          select sub_id
            from dsubprojeto
           where upper(trim(sub_depara)) = vc_origem
             and pro_id = vc_proj;
             
begin
  v_dt := timeofday();
  for regi in (select *
                 from fimpdfc_ms a
                where a.ims_id = p_idimport)
  loop
/*    delete from fdfc_lacto
     where imi_id in (select imi_id from fimpdfc_dt where ims_id = regi.ims_id);*/
     
    v_proj := regi.pro_id;
    v_erro := 0;
    for reg in (select *
                  from fimpdfc_dt b
                 where b.ims_id = regi.ims_id  order by b.imi_id)
    loop
      v_msgerro :=  null;
      v_forcli := null;
      if trim(reg.imi_nomeclifor) is null and trim(reg.imi_cnpjcpf) is null then
         v_msgerro := 'Fornecedor / Cliente não informado !';
      else
         v_forcli := null;
         open cr_clifor_razao (upper(trim(reg.imi_nomeclifor)), regi.pro_id);
         fetch cr_clifor_razao into v_forcli;
         close cr_clifor_razao;
         if v_forcli is null then
            open cr_clifor_cnpj (upper(trim(reg.imi_cnpjcpf)), regi.pro_id);
            fetch cr_clifor_cnpj into v_forcli;
            close cr_clifor_cnpj;
            if v_forcli is null then
               select nextval('seq_dcliente') into v_forcli;
               insert into dclifor (cli_id,   cli_nome,                             pro_id,      cli_dtsis, cli_cnpjcpf)
                            values (v_forcli, upper(TRIM(from reg.imi_nomeclifor)), regi.pro_id, v_dt,      reg.imi_cnpjcpf);
            end if;
         end if;
      end if;
      v_plaid := null;
      open cr_planoconta (reg.imi_conta, regi.pro_id);
      fetch cr_planoconta into v_plaid;
      close cr_planoconta;
      if v_plaid is null THEN
         v_msgerro := coalesce(v_msgerro,' ')||' Rubrica não cadastrada ou Nao aceita lcto !';
      end if;
      if reg.imi_dtemissao is null THEN
         v_msgerro := coalesce(v_msgerro,' ')||' Dt de emissão não informada !';
      end if;
      if reg.imi_dtvenc_ajustada is null THEN
         v_msgerro := coalesce(v_msgerro,' ')||' Dt de vecto ajustada não informada !';
      end if;
      if reg.imi_dtvenc_orig is null THEN
         v_msgerro := coalesce(v_msgerro,' ')||' Dt de vecto não informada !';
      end if;
      if reg.imi_vlmovim = 0 THEN
         v_msgerro := coalesce(v_msgerro,' ')||' Valor não informado (zero)!';
      end if;
      if reg.imi_vlprevisto = 0 THEN
         v_msgerro := coalesce(v_msgerro,' ')||' Valor Previsto não informado (zero)!';
      end if;
      if reg.imi_vlmovim < 0 THEN
         v_msgerro := coalesce(v_msgerro,' ')||' Valor negativo !';
      end if;
      if reg.imi_vlprevisto < 0 THEN
         v_msgerro := coalesce(v_msgerro,' ')||' Valor previsto negativo !';
      end if;
      v_subid := null;
      if trim(reg.imi_subprojeto) is not null then
         open cr_subcon (upper(trim(reg.imi_subprojeto)), regi.pro_id);
         fetch cr_subcon into v_subid;
         close cr_subcon;
      end if;
      if v_subid is null then
         v_msgerro := coalesce(v_msgerro,' ')||'Sub Projeto não informado !';
      end if;
      if v_msgerro is null then
         v_count := 0;
         select count(*) into v_count
           from fdfc_lacto u
          where u.pro_id = regi.pro_id
            and u.cli_id = v_forcli
            and u.dfc_docto = reg.imi_docto
            and u.dfc_serie = reg.imi_serie
            and u.dfc_parcela = reg.imi_parcela;
         if v_count = 0 then
            insert into fdfc_lacto (pro_id,             usu_id,                 cli_id,              dfc_vlprevisto,     dfc_vlmovim,     dfc_dtmovim,
                                    dfc_dtemissao,      dfc_venc_ajustada,      dfc_dtvenc_orig,     dfc_docto,          dfc_serie,       dfc_parcela,
                                    pla_id,            sub_id,                  imi_id,              dfc_impdig)
                            values (regi.pro_id,       regi.usu_id,             v_forcli,            reg.imi_vlprevisto, reg.imi_vlmovim, reg.imi_dtmovim,
                                    reg.imi_dtemissao, reg.imi_dtvenc_ajustada, reg.imi_dtvenc_orig, reg.imi_docto,      reg.imi_serie,   reg.imi_parcela,
                                    v_plaid,           v_subid,                 reg.imi_id,          'I' );
            update fimpdfc_dt set imi_status = 'Ok Inclusão', pla_id = v_plaid
             where imi_id = reg.imi_id;
         else
            update fdfc_lacto x set dfc_vlprevisto = reg.imi_vlprevisto, dfc_vlmovim = reg.imi_vlmovim,                dfc_dtmovim = reg.imi_dtmovim,
                                    dfc_dtemissao = reg.imi_dtemissao,   dfc_venc_ajustada =  reg.imi_dtvenc_ajustada, dfc_dtvenc_orig = reg.imi_dtvenc_orig,
                                    pla_id = v_plaid,                    sub_id = v_subid,                             imi_id = reg.imi_id
             where x.pro_id = regi.pro_id
               and x.cli_id = v_forcli
               and x.dfc_docto = reg.imi_docto
               and x.dfc_serie = reg.imi_serie
               and x.dfc_parcela = reg.imi_parcela;
            update fimpdfc_dt set imi_status = 'Ok Alteração', pla_id = v_plaid
             where imi_id = reg.imi_id;
         end if;
      else
         update fimpdfc_dt set imi_status = v_msgerro
          where imi_id = reg.imi_id;
         v_erro := v_erro + 1;
      end if;
    end loop;
    if v_erro > 0 then
       delete from fdfc_lacto where imi_id = p_idimport;
    end if;
  end loop;
  return true;
end;
$$;

alter function prc_chk_imp_dfc(integer) owner to dba;

