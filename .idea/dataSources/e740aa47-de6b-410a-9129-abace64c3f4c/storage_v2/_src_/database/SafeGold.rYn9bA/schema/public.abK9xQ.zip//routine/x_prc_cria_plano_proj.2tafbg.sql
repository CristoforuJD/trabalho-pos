create function x_prc_cria_plano_proj(p_grupo integer, p_padrao_id integer, p_projeto integer) returns void
    language plpgsql
as
$$
declare
--
-- Giba 10/2016
-- Copia o plano de contas padrao para o plano do projeto, se o projeto nao tiver plano algum
--
reg     record;
x       record;
pai     record;
v_count integer;
v_id    integer;
v_dt    timestamp;
v_ano   integer;
v_mes   integer;
begin
  v_count := 0;
  select count(*) into v_count
    from planoconta
   where pro_id = p_projeto;
  if v_count = 0 then 
     v_dt := timeofday();

     for x in (select *
                 from planopadrao
                where gru_id = p_grupo
                  and plp_id = p_padrao_id
                  and plp_ativo = 'A')
     loop
      for reg in (select * from contapadrao where plp_id = x.plp_id order by clp_ordem)
      loop
        SELECT nextval('planoconta_pla_id_seq') into v_id;
        insert into planoconta (pla_id,           pla_nivel,     pla_nome,        pla_valorperc,     pla_valorperco,     pla_totsn,
                                pro_id,           pla_ordem,     clp_id,          pla_corfundo,      pla_datasis,        pla_edtpero,
                                pla_corfonte,     pla_bold,      pla_edtvlrf,     pla_edtvlro,       pla_edtperf,        pla_subordem,
                                pla_transferencia, pla_lvd, pla_recnopera, pla_origem_aplic,
                                pla_criafilho)
                        values (v_id,             reg.clp_nivel, reg.clp_nome,    reg.clp_valorperc, reg.clp_valorperco, reg.clp_totsn,
                                p_projeto,        reg.clp_ordem, reg.clp_id,      reg.clp_corfundo,  v_dt,               reg.clp_edtpero,
                                reg.clp_corfonte, reg.clp_bold,  reg.clp_edtvlrf, reg.clp_edtvlro,   reg.clp_edtperf,    1,
                                reg.clp_transferencia, reg.clp_lvd, reg.clp_recnopera, reg.clp_origem_aplic,
                                reg.clp_criafilho);
--        insert into deparacta (pla_id, dep_contacli, pro_id) values (v_id, reg.clp_nome, p_projeto);
      end loop;
      
      for pai in (select a.pla_id, c.pla_id id_pai
                    from planoconta a, contapadrao b, planoconta c
                   where a.pro_id = p_projeto
                     and b.clp_id = a.clp_id
                     and b.clp_idpai is not NULL
                     and c.pro_id = p_projeto
                     and c.clp_id = b.clp_idpai)
      loop
        update planoconta set pla_idpai = pai.id_pai
         where pla_id = pai.pla_id;
      end loop;               
      
     end loop;
  end if;
--
-- Gera ordem disponivel para inclusao de futuras contas no plano de contas
--
  perform prc_ordem_disponivel(p_projeto);
--
-- Gera calendario e tabela timeout para tres meses futuro e tres meses ao passado da data atual + mes e ano atual
--
  select date_part('year',CURRENT_DATE), date_part('month',CURRENT_DATE) into v_ano, v_mes;
  perform prc_gera_calendario(p_projeto,v_ano,v_mes);

  select date_part('year',date_trunc('month',current_date) + INTERVAL'3 month' - INTERVAL'0 day'),
         date_part('month',date_trunc('month',current_date) + INTERVAL'3 month' - INTERVAL'0 day') into v_ano, v_mes;
  perform prc_gera_calendario(p_projeto,v_ano,v_mes);

  select date_part('year',date_trunc('month',current_date) + INTERVAL'2 month' - INTERVAL'0 day'),
         date_part('month',date_trunc('month',current_date) + INTERVAL'2 month' - INTERVAL'0 day') into v_ano, v_mes;
  perform prc_gera_calendario(p_projeto,v_ano,v_mes);

  select date_part('year',date_trunc('month',current_date) + INTERVAL'1 month' - INTERVAL'0 day'),
         date_part('month',date_trunc('month',current_date) + INTERVAL'1 month' - INTERVAL'0 day') into v_ano, v_mes;
  perform prc_gera_calendario(p_projeto,v_ano,v_mes);
  
  select date_part('year',date_trunc('month',current_date) - INTERVAL'3 month' - INTERVAL'0 day'),
         date_part('month',date_trunc('month',current_date) - INTERVAL'3 month' - INTERVAL'0 day') into v_ano, v_mes;
  perform prc_gera_calendario(p_projeto,v_ano,v_mes);

  select date_part('year',date_trunc('month',current_date) - INTERVAL'2 month' - INTERVAL'0 day'),
         date_part('month',date_trunc('month',current_date) - INTERVAL'2 month' - INTERVAL'0 day') into v_ano, v_mes;
  perform prc_gera_calendario(p_projeto,v_ano,v_mes);

  select date_part('year',date_trunc('month',current_date) - INTERVAL'1 month' - INTERVAL'0 day'),
         date_part('month',date_trunc('month',current_date) - INTERVAL'1 month' - INTERVAL'0 day') into v_ano, v_mes;
  perform prc_gera_calendario(p_projeto,v_ano,v_mes);

  return;
end;
$$;

alter function x_prc_cria_plano_proj(integer, integer, integer) owner to dba;

