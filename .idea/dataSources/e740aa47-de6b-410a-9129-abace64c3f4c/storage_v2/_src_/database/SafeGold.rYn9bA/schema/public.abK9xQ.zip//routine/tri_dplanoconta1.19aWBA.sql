create function tri_dplanoconta1() returns trigger
    language plpgsql
as
$$
DECLARE

v_count integer;

begin
  if TG_OP in ('INSERT','UPDATE') then
     new.pla_nome := upper(TRIM(new.pla_nome));
  end if;
  Return New;
end;
$$;

alter function tri_dplanoconta1() owner to dba;

