create function x_prc_cheka_pagar(p_idimport integer) returns boolean
    language plpgsql
as
$$
declare
--
-- Giba 11/2016
-- Confere importacao de contas a pagar
--
reg         record;
regi        record;
v_dt        timestamp;
v_msgerro   varchar(255);
v_forid     integer;
v_erro      integer;
v_plaid     integer;
v_subid     integer;
v_doctedo   varchar(01);
v_proj      integer;
v_fornec    VARCHAR(100);

cr_fornecedor_razao cursor (vc_for varchar, vc_proj integer) is
                    select for_id
                     from deparafornec
                    where upper(trim(def_nomeimp)) = upper(trim(vc_for))
                      and pro_id = vc_proj;

cr_planoconta cursor (vc_plano varchar, vc_proid integer) is
              select a.pla_id
                from deparacta a, planoconta b
               where a.pro_id = vc_proid
                 and UPPER(TRIM(a.dep_contacli)) = UPPER(TRIM(vc_plano))
                 and b.pla_id = a.pla_id
                 and b.pla_totsn = 'N';
           
cr_subcon cursor (vc_origem varchar, vc_proj integer) is
          select sub_id
            from subprojeto
           where upper(trim(sub_empresa_depara)) = vc_origem
             and pro_id = vc_proj;
             
begin
  v_dt := timeofday();
  for regi in (select a.*, b.sub_id_caixa
                 from calenativ a, projeto b
                where a.imp_id = p_idimport
                  and b.pro_id = a.pro_id)
  loop
    delete from pagar
     where pag_database = regi.imp_database
       and pro_id = regi.pro_id;
    v_proj := regi.pro_id;
    v_erro := 0;
    for reg in (select *
                  from imppagar b
                 where b.imp_id = regi.imp_id)
    loop
      v_msgerro :=  null;
      v_forid := null;
      if trim(reg.ipg_favorecido) is null then
         v_msgerro := 'Fornecedor não informado !';
      else
         open cr_fornecedor_razao (upper(trim(from reg.ipg_favorecido)), regi.pro_id);
         fetch cr_fornecedor_razao into v_forid;
         close cr_fornecedor_razao;
         if v_forid is null then
            select nextval('fornecedor_seq') into v_forid;
            insert into fornecedor (for_id,  for_razao,                            pro_id,      for_datasis, for_cnpj)
                            values (v_forid, upper(TRIM(from reg.ipg_favorecido)), regi.pro_id, v_dt,        reg.ipg_cnpj);
         end if;
      end if;
      v_plaid := null;
      open cr_planoconta (reg.ipg_rubrica, regi.pro_id);
      fetch cr_planoconta into v_plaid;
      close cr_planoconta;
      if v_plaid is null THEN
         v_msgerro := coalesce(v_msgerro,' ')||' Rubrica não cadastrada !';
      end if;
      if reg.ipg_docted in ('D','DOC') THEN
         v_doctedo := 'D';
      elsif reg.ipg_docted in ('T','TED') THEN
            v_doctedo := 'T';
         else
            v_doctedo := 'O';
      end if;
      if reg.ipg_emissao is null THEN
         v_msgerro := coalesce(v_msgerro,' ')||' Dt de emissão não informada !';
      end if;
      if reg.ipg_vecto is null THEN
         v_msgerro := coalesce(v_msgerro,' ')||' Dt de vecto não informada !';
      end if;
      if reg.ipg_valor = 0 THEN
         v_msgerro := coalesce(v_msgerro,' ')||' Valor não informado (zero)!';
      end if;
      if reg.ipg_valor is null THEN
         v_msgerro := coalesce(v_msgerro,' ')||' Valor não informado (nulo)!';
      end if;
      if reg.ipg_valor < 0 THEN
         v_msgerro := coalesce(v_msgerro,' ')||' Valor a pagar negativo !';
      end if;
      if trim(reg.ipg_cons) is not null then
         open cr_subcon (upper(trim(reg.ipg_cons)), regi.pro_id);
         fetch cr_subcon into v_subid;
         close cr_subcon;
      else
         v_subid := regi.sub_id_caixa;
      end if;
      if v_subid is null then
         v_msgerro := coalesce(v_msgerro,' ')||'Sub Projeto não informado !';
      end if;      
      if v_msgerro is null then
         insert into pagar (pag_emissao,       pag_vecto,     pag_doc,     pag_cheque,     pag_valor,     pag_docted,
                            pag_database,      pag_datasis,   pla_id,      ipg_id,         for_id,
                            pro_id,            sub_id,        imp_id,      pag_origem)
                    values (reg.ipg_emissao,   reg.ipg_vecto, reg.ipg_doc, reg.ipg_cheque, trunc(reg.ipg_valor,2), v_doctedo,
                            regi.imp_database, v_dt,          v_plaid,     reg.ipg_id,     v_forid,
                            regi.pro_id,       v_subid,       regi.imp_id, reg.ipg_origem);
         update imppagar set ipg_msgerro = null
          where ipg_id = reg.ipg_id;
      else
         update imppagar set ipg_msgerro = v_msgerro
          where ipg_id = reg.ipg_id;
         v_erro := v_erro + 1;
      end if;
    end loop;
    if v_erro > 0 then
       delete from pagar where imp_id = p_idimport;
       update calenativ set usu_id_pag = null, imp_data_pag = null
        where imp_id = p_idimport;
    end if;
  end loop;
  return true;
end;
$$;

alter function x_prc_cheka_pagar(integer) owner to dba;

