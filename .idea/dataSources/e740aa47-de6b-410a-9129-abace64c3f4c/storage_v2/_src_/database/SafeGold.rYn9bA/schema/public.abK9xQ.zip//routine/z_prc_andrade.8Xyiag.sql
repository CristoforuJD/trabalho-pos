create function z_prc_andrade(p_empre integer) returns void
    strict
    language plpgsql
as
$$
declare
--
-- Giba 12/2018
--
v_count integer;
reg record;
pos record;
ant record;
fre record;
v_novo_custo   numeric;
begin
 v_count := 0;
    update zgiba set nome = v_count
    where id in (2,3);
 for reg in (select codpro, data, preven, and_id, custo
               from z_andrade
              where (custo > preven or custo = 0)
                and empresa = p_empre)
--                and and_id = 659052)
 loop
   v_novo_custo := 0;
   for ant in (select custo
                 from z_andrade
                where codpro = reg.codpro
                  and data <=reg.data
                  and custo < reg.preven order by data DESC)
   loop
     v_novo_custo := ant.custo;
     exit;
   end loop;
   v_count := v_count + 1;
   if v_novo_custo > 0 then
      update z_andrade set custo_safe = v_novo_custo, custo_notfound = 9
       where and_id = reg.and_id;
   else
      update z_andrade set custo_safe = reg.custo, custo_notfound = 1
       where and_id = reg.and_id;
   end if;
   update zgiba set nome = v_count
    where id = 2;
    --RAISE NOTICE '1.o loop %', v_count;
 end loop;
 
 for pos in (select codpro, data, preven, and_id, custo
               from z_andrade
              where (custo > preven or custo = 0)
                and custo_notfound = 1
                and empresa = p_empre)
--                and and_id = 459046)
 loop
   v_novo_custo := 0;
   for fre in (select custo
                 from z_andrade
                where codpro = pos.codpro
                  and data >= pos.data
                  and custo < pos.preven order by data)
   loop
     v_novo_custo := fre.custo;
     exit;
   end loop;
   v_count := v_count + 1;
   if v_novo_custo > 0 then
      update z_andrade set custo_safe = v_novo_custo, custo_notfound = 8
       where and_id = pos.and_id;
   else
      update z_andrade set custo_safe = pos.custo, custo_notfound = 1
       where and_id = pos.and_id;
   end if;
   update zgiba set nome = v_count
    where id = 3;
--    RAISE NOTICE '2.o loop %', v_count;
 end loop;
-- update z_andrade set custo_safe = custo where custo_notfound = 0 and empresa = p_empre;
 return;
end;
$$;

alter function z_prc_andrade(integer) owner to dba;

