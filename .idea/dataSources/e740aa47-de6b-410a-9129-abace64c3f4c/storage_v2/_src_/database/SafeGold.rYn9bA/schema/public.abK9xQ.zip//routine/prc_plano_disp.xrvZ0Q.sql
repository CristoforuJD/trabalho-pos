create function prc_plano_disp(p_proj integer) returns void
    strict
    language plpgsql
as
$$
declare
--
-- Giba 09/2018
-- Cria relacao das ordens disponivels para placonta de todos os projetos
--
v_count integer;
reg record;
nv3 record;
pro record;
v_next   integer;
begin
 for pro in (select * from dprojeto where pro_id = p_proj)
 loop
   delete from dplanodisp where pro_id = pro.pro_id;
   for reg in (select *
                 from dplanoconta
                where pro_id = pro.pro_id 
                  and pla_nivel = 2
                 -- and pla_ordem = 5000
                  and pla_ordem_ini > 0
                  and pla_ordem_fim > 0
                  and pla_ordem_fim > pla_ordem_ini order by pla_ordem)
   loop
      v_next := reg.pla_ordem_ini;
      while v_next <= reg.pla_ordem_fim
      loop
        insert into dplanodisp (pro_id,     pla_idpai,  pla_ordem)
                        values (reg.pro_id, reg.pla_id, v_next);
        v_next := v_next + 1;
      end loop;
      for nv3 in (select a.pla_id, a.pla_idpai, a.pla_ordem
                    from dplanoconta a
                   where a.pla_idpai = reg.pla_id)
      loop
--        RAISE NOTICE '%', 'Antes update '||nv3.pla_id||' Ordem '||nv3.pla_ordem||' Projeto '||reg.pro_id;
        update dplanodisp set pla_id = nv3.pla_id
         where pro_id = reg.pro_id
           and pla_ordem = nv3.pla_ordem;
--        RAISE NOTICE '%', 'Depois update '||nv3.pla_id||' Ordem '||nv3.pla_ordem;
      end loop;
   end loop;
 end loop;
 return;
end;
$$;

alter function prc_plano_disp(integer) owner to dba;

