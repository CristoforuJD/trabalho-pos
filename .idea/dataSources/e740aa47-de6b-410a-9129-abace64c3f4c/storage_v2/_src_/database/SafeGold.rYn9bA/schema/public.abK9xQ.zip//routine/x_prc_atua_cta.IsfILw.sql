create function x_prc_atua_cta(p_idctapai integer, p_ano integer, p_mes integer, p_sub integer, p_valoro numeric DEFAULT 0, p_perco numeric DEFAULT 0, p_valorr numeric DEFAULT 0, p_percr numeric DEFAULT 0, p_tarifa numeric DEFAULT 0, p_pagos numeric DEFAULT 0, p_trans numeric DEFAULT 0, p_pagar numeric DEFAULT 0, p_previ numeric DEFAULT 0, p_opera numeric DEFAULT 0) returns void
    language plpgsql
as
$$
declare
--
-- Giba 10/2016
-- Atualiza uma conta DRE recursivamente de um mes/ano de um sub-projeto DocOk
--
x        record;
begin
  if p_idctapai is not null then
     for x in (select a.pla_idpai
                 from planoconta a
                where a.pla_id = p_idctapai)
     loop
       update drefechaorca set dre_orc = dre_orc + p_valoro, dre_real = dre_real + p_valorr,
                               dre_orc_per = dre_orc_per + p_perco, dre_real_per = dre_real_per + p_percr
        where pla_id  = p_idctapai
          and dre_ano = p_ano
          and dre_mes = p_mes
          and sub_id  = p_sub;
       perform prc_atua_cta (x.pla_idpai, p_ano, p_mes, p_sub, p_valoro, p_perco, p_valorr, p_percr);
     end loop;
  end if;
  return;
end;
$$;

alter function x_prc_atua_cta(integer, integer, integer, integer, numeric, numeric, numeric, numeric, numeric, numeric, numeric, numeric, numeric, numeric) owner to dba;

